# InteraptLostAndFound
Project Title:     Lost and Found app
Project Date:      6/21/2018 - 6/22/2018
Project Memebers:  Jon Leohr, Jillian Maher, Ben Hammond
Project Description:
Our brainstorm baby of lost and found items for our project during Interapt training
